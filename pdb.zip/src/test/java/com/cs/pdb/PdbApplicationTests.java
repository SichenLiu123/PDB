package com.cs.pdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdbApplicationTests {

    @Test
    void contextLoads() {
    }

}
